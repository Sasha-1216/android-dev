package com.example.project2


import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import kotlin.collections.*
import android.widget.EditText
import android.widget.ListView
import androidx.annotation.LayoutRes
import androidx.core.view.isGone
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_home.view.*

/**
 * A simple [Fragment] subclass.
 */
class HomeFragment : Fragment() {


    private lateinit var studentNameEdit: EditText

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        studentNameView.text = studentInfo.name
        redIdView.text = studentInfo.redID
        emailView.text = studentInfo.email

        val listView = view.findViewById<ListView>(R.id.registered_courses)
        var registeredCourses : MutableList<Course> = mutableListOf<Course>()
        for (course in availableCourses) {
            if (course.selected) {
                registeredCourses.add(course)
            }
        }
        val listViewAdapter = MyListAdapterHome(
            view.context,
            android.R.layout.simple_list_item_1,
            registeredCourses
        )

        listView.adapter = listViewAdapter

    }

//    class CourseAdapter(context: Context, @LayoutRes resource: Int, private val availableCourses: List<Course>) :
//        ArrayAdapter<Course>(context, resource, availableCourses) {
//
//        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
//
//            val v = super.getView(position, convertView, parent)
//            println("Looking at $position")
//            if (!availableCourses[position].selected) {
//                println("Setting $position to gone")
//                v.visibility = View.GONE
//            }
//
//            return v
//        }
//    }

}
