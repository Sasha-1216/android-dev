package com.example.project2

import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.*
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.*
import android.widget.ListView
import android.R.layout.*
import android.R.color.*
import kotlinx.android.synthetic.*
import android.R.layout.*
import android.content.Intent
import androidx.annotation.LayoutRes
import kotlinx.android.synthetic.main.activity_main.view.*


/**
 * A simple [Fragment] subclass.
 */
class CourseFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val view: View = inflater.inflate(R.layout.fragment_course, container, false)
        val listView = view.findViewById<ListView>(R.id.course_list_view)
        val listViewAdapter = MyListAdapter(
            view.context,
            simple_list_item_1,
            availableCourses
        )

        listView.adapter = listViewAdapter


        listView.setOnItemClickListener { parent, view, position, id ->
            availableCourses[id.toInt()].selected = !availableCourses[id.toInt()].selected
            println("${availableCourses[id.toInt()]} chosen: ${availableCourses[id.toInt()].selected}")
            if (availableCourses[id.toInt()].selected) {
                view.setBackgroundColor(ContextCompat.getColor(context as Context, R.color.selected))
            } else {
                view.setBackgroundColor(Color.TRANSPARENT)
            }
            listViewAdapter.notifyDataSetChanged()
        }

        return view
    }

//    class CourseAdapter(context: Context, @LayoutRes resource: Int, private val availableCourses: List<Course>) :
//        ArrayAdapter<Course>(context, resource, availableCourses) {
//
//        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
//
//            val v = super.getView(position, convertView, parent)
//            println("Looking at $position")
//            if (availableCourses[position].selected) {
//                println("Setting $position")
//                v.setBackgroundColor(Color.GREEN)
//            }
//            else {
//                v.setBackgroundColor(Color.TRANSPARENT)
//            }
//            return v
//        }
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        return
    }

}
